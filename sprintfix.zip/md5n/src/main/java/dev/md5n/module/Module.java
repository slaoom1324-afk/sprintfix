package dev.md5n.module;

import dev.md5n.setting.BoolSetting;
import dev.md5n.setting.KeySetting;
import dev.md5n.setting.ModeSetting;
import dev.md5n.setting.NumSetting;
import dev.md5n.setting.Setting;
import dev.md5n.util.Sfx;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    public final String name;
    public final Category category;
    public final String description;

    private boolean enabled;
    private int key = -1;     // مفتاح تشغيل المود (GLFW)، -1 = بدون
    boolean keyDown;          // لحساب الضغطة مرة وحدة
    private final List<Setting> settings = new ArrayList<>();

    protected Module(String name, Category category, String description) {
        this.name = name;
        this.category = category;
        this.description = description;
    }

    protected BoolSetting bool(String settingName, boolean def, String desc) {
        BoolSetting s = new BoolSetting(settingName, def, desc);
        settings.add(s);
        return s;
    }

    protected NumSetting num(String settingName, double def, double min, double max, double step, String desc) {
        NumSetting s = new NumSetting(settingName, def, min, max, step, desc);
        settings.add(s);
        return s;
    }

    protected ModeSetting mode(String settingName, String def, String desc, String... modes) {
        ModeSetting s = new ModeSetting(settingName, def, desc, modes);
        settings.add(s);
        return s;
    }

    protected KeySetting keybind(String settingName, int def, String desc) {
        KeySetting s = new KeySetting(settingName, def, desc);
        settings.add(s);
        return s;
    }

    public List<Setting> settings() { return settings; }

    public int getKey() { return key; }

    public void setKey(int key) { this.key = key; }

    public boolean isEnabled() { return enabled; }

    /** ترتيب رسم الـ HUD: 0 = خلفية (سماء/ضباب)، 1 = عادي، 2 = فوق كل شي. */
    public int hudLayer() { return 1; }

    /** false = صفحة إعدادات فقط (مثل Theme)، ما تتشغّل وتتطفى. */
    public boolean hasToggle() { return true; }

    public void toggle() {
        boolean before = enabled;
        setEnabled(!enabled);
        if (enabled != before) {
            if (enabled) Sfx.on(); else Sfx.off();
        }
    }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        if (value) onEnable(); else onDisable();
    }

    protected void onEnable() {}
    protected void onDisable() {}
    public void onTick() {}
    public void onHudRender(DrawContext ctx) {}
}
