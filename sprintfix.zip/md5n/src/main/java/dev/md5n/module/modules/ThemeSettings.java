package dev.md5n.module.modules;

import dev.md5n.module.Category;
import dev.md5n.module.Module;
import dev.md5n.setting.BoolSetting;
import dev.md5n.setting.ModeSetting;
import dev.md5n.setting.NumSetting;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

public class ThemeSettings extends Module {
    private record Palette(int accent, int header, int off, int hover, int on,
                           int setting, int settingHover, int text, int subtext,
                           int track, int good, int bad, int bind) {}

    private static final Palette CYAN = new Palette(0xFF55FFFF, 0xFF14141F, 0xFF2A2A3A, 0xFF3A3A4A, 0xFF2E7D32,
            0xFF1C1C28, 0xFF242433, 0xFFFFFFFF, 0xFFAAAAAA, 0xFF3A3A4A, 0xFF55FF55, 0xFFFF5555, 0xFFFFD54F);
    private static final Palette EMERALD = new Palette(0xFF7CFFC4, 0xFF0B2217, 0xFF14402B, 0xFF1E5A3E, 0xFF2E9E62,
            0xFF0F301F, 0xFF184228, 0xFFFFFFFF, 0xFFB5E8CF, 0xFF1E5A3E, 0xFF6CFF9C, 0xFFFF6B6B, 0xFFFFD54F);
    private static final Palette PURPLE = new Palette(0xFFB388FF, 0xFF1A1028, 0xFF2A2236, 0xFF3A3048, 0xFF6A3FB5,
            0xFF201830, 0xFF2A2040, 0xFFFFFFFF, 0xFFB0A0C8, 0xFF3A3048, 0xFF69F0AE, 0xFFFF5252, 0xFFFFD54F);
    private static final Palette RED = new Palette(0xFFFF5252, 0xFF1F1010, 0xFF2E1E1E, 0xFF3E2A2A, 0xFFB71C1C,
            0xFF241414, 0xFF2E1C1C, 0xFFFFFFFF, 0xFFC8A0A0, 0xFF3E2A2A, 0xFF69F0AE, 0xFFFFAB91, 0xFFFFD54F);
    private static final Palette GREEN = new Palette(0xFF69F0AE, 0xFF0F1F16, 0xFF1E2E24, 0xFF2A3E32, 0xFF2E7D32,
            0xFF14241B, 0xFF1C2E24, 0xFFFFFFFF, 0xFFA0C8B0, 0xFF2A3E32, 0xFF69F0AE, 0xFFFF5252, 0xFFFFD54F);
    private static final Palette PINK = new Palette(0xFFFF80AB, 0xFF1F1018, 0xFF2E1E26, 0xFF3E2A36, 0xFFC2185B,
            0xFF24141C, 0xFF2E1C26, 0xFFFFFFFF, 0xFFC8A0B0, 0xFF3E2A36, 0xFF69F0AE, 0xFFFF5252, 0xFFFFD54F);
    private static final Palette MONO = new Palette(0xFFFFFFFF, 0xFF111111, 0xFF222222, 0xFF333333, 0xFF555555,
            0xFF181818, 0xFF202020, 0xFFFFFFFF, 0xFF999999, 0xFF333333, 0xFFFFFFFF, 0xFF888888, 0xFFFFFFFF);
    private static final Palette LIGHT = new Palette(0xFF1565C0, 0xFFE0E0E8, 0xFFF2F2F6, 0xFFE4E4EC, 0xFF81C784,
            0xFFE8E8F0, 0xFFDCDCE6, 0xFF1A1A1A, 0xFF666666, 0xFFC8C8D4, 0xFF2E7D32, 0xFFC62828, 0xFFE65100);

    private final ModeSetting theme = mode("Theme", "Emerald", "Color preset for the menu and HUD",
            "Emerald", "Cyan", "Purple", "Red", "Green", "Pink", "Mono", "Light");
    private final ModeSetting style = mode("Style", "Glass", "Glass = rounded glowing panels, Classic = flat panels",
            "Glass", "Classic");
    private final BoolSetting rainbow = bool("Rainbow Accent", false, "Animated rainbow accent color");
    private final NumSetting rainbowSpeed = num("Rainbow Speed", 4, 1, 10, 1, "How fast the rainbow cycles");
    private final NumSetting panelWidth = num("Panel Width", 150, 120, 260, 10, "Width of each menu panel");
    private final NumSetting rowHeight = num("Row Height", 16, 16, 24, 1, "Height of each menu row");
    private final NumSetting opacity = num("Panel Opacity", 1.0, 0.4, 1.0, 0.05, "Background opacity of the menu");
    private final BoolSetting animations = bool("Animations", true, "Smooth hover, toggle and open animations");
    private final BoolSetting sounds = bool("Sounds", true, "Click sounds when using the menu and toggling modules");
    private final ModeSetting menuKey = mode("Menu Key", "RShift+Space", "Key combo that opens the menu",
            "RShift+Space", "RShift", "Insert", "RAlt");

    public ThemeSettings() {
        super("Theme", Category.CLIENT, "Menu colors, layout, sounds and menu key");
    }

    // مو مود يتشغّل ويتطفى، بس صفحة إعدادات
    @Override
    public boolean hasToggle() { return false; }

    @Override
    public void setEnabled(boolean value) {}

    private Palette palette() {
        return switch (theme.get()) {
            case "Cyan" -> CYAN;
            case "Purple" -> PURPLE;
            case "Red" -> RED;
            case "Green" -> GREEN;
            case "Pink" -> PINK;
            case "Mono" -> MONO;
            case "Light" -> LIGHT;
            default -> EMERALD;
        };
    }

    private int alpha(int color) {
        int a = (int) (opacity.get() * 255);
        return (color & 0x00FFFFFF) | (a << 24);
    }

    private static int scale(int argb, float f) {
        int r = (int) (((argb >> 16) & 0xFF) * f);
        int g = (int) (((argb >> 8) & 0xFF) * f);
        int b = (int) ((argb & 0xFF) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    public int accent() {
        if (rainbow.get()) {
            double period = 10000.0 / rainbowSpeed.get();
            float hue = (float) ((System.currentTimeMillis() % (long) period) / period);
            return 0xFF000000 | MathHelper.hsvToRgb(hue, 0.55f, 1.0f);
        }
        return palette().accent();
    }

    public int header() { return alpha(palette().header()); }
    public int off() { return alpha(palette().off()); }
    public int hover() { return alpha(palette().hover()); }
    public int on() { return alpha(rainbow.get() ? scale(accent(), 0.45f) : palette().on()); }
    public int setting() { return alpha(palette().setting()); }
    public int settingHover() { return alpha(palette().settingHover()); }
    public int text() { return palette().text(); }
    public int subtext() { return palette().subtext(); }
    public int track() { return palette().track(); }
    public int good() { return palette().good(); }
    public int bad() { return palette().bad(); }
    public int bind() { return palette().bind(); }

    public int panelWidth() { return panelWidth.getInt(); }
    public int rowHeight() { return rowHeight.getInt(); }
    public boolean animations() { return animations.get(); }
    public boolean sounds() { return sounds.get(); }
    public boolean glass() { return style.is("Glass"); }

    private static boolean down(long window, int key) {
        return InputUtil.isKeyPressed(window, key);
    }

    /** هل الضغطة الحالية هي مفتاح القائمة؟ (تستخدم لفتح القائمة) */
    public boolean menuHeld(long window) {
        return switch (menuKey.get()) {
            case "RShift" -> down(window, GLFW.GLFW_KEY_RIGHT_SHIFT);
            case "Insert" -> down(window, GLFW.GLFW_KEY_INSERT);
            case "RAlt" -> down(window, GLFW.GLFW_KEY_RIGHT_ALT);
            default -> down(window, GLFW.GLFW_KEY_RIGHT_SHIFT) && down(window, GLFW.GLFW_KEY_SPACE);
        };
    }

    /** هل هذا الحدث (من داخل القائمة) يمثل مفتاح القائمة؟ (تستخدم لإغلاقها) */
    public boolean menuMatches(int keyCode, long window) {
        return switch (menuKey.get()) {
            case "RShift" -> keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT;
            case "Insert" -> keyCode == GLFW.GLFW_KEY_INSERT;
            case "RAlt" -> keyCode == GLFW.GLFW_KEY_RIGHT_ALT;
            default -> (keyCode == GLFW.GLFW_KEY_SPACE && down(window, GLFW.GLFW_KEY_RIGHT_SHIFT))
                    || (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT && down(window, GLFW.GLFW_KEY_SPACE));
        };
    }
}
